import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregar-pregunta',
  templateUrl: './agregar-pregunta.component.html',
  styleUrls: ['./agregar-pregunta.component.css']
})
export class AgregarPreguntaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
