import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregar-examen',
  templateUrl: './agregar-examen.component.html',
  styleUrls: ['./agregar-examen.component.css']
})
export class AgregarExamenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
