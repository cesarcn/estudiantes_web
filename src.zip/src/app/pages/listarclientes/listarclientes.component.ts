import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listarclientes',
  templateUrl: './listarclientes.component.html',
  styleUrls: ['./listarclientes.component.css']
})
export class ListarclientesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
